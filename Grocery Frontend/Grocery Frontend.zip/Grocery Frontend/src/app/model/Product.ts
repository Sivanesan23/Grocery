export class Product {
    id: number;
    name: string;
    price: number;
    picByte: string;
    retrievedImage: string;
    isAdded: boolean;    
    }